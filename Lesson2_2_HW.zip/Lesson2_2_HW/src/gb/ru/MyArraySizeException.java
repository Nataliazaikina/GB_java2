package gb.ru;

public class MyArraySizeException extends Exception {
}
