package gb.ru;



public class Main {


    public static void main(String[] args) {

        try {
            int sum = sum2DArray(new String[][] {
                    {"1", "2", "3", "4"},
                    {"5", "6", "7", "8"},
                    {"9", "10", "11", "12"},
                    {"13", "14", "15", "16"}
            });
            System.out.println(sum);
        } catch (MyArraySizeException e) {
            e.printStackTrace();
            System.out.println("Ошибка с размером массива");
        } catch (MyArrayDataException e) {
            e.printStackTrace();
            System.out.println(e.getError());
        }
    }

        
        public static int sum2DArray(String[][] toSum) throws MyArraySizeException, MyArrayDataException {
            if (toSum.length !=4) {
                throw new MyArraySizeException();
            }
            for (String[] array : toSum) {
                if (array.length !=4) {
                    throw new MyArraySizeException();
                }
            }
            int sum = 0;
            for (int i = 0; i < toSum.length; i++) {
                for (int j = 1; j < toSum[i].length; j++) {
                    try {
                        sum += Integer.parseInt(toSum[i][j]);
                    } catch (NumberFormatException ex) {
                        throw new MyArrayDataException(i, j);
                    }
                }
            }
            return sum;
        }
}
