package HW2.ru;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PhoneBook {
    Map<String, List<String>> phoneBook;
    public PhoneBook {
        this.phoneBook = new HashMap<>();
    }

    public void add(String surname, String phonenumber) {
        phoneBook.put(surname, new ArrayList<>());
    }

    public List<String> get(String surname) {
        return phoneBook.get(surname);
    }
    public static void main(String[] args) {
        PhoneBook phoneBook = new PhoneBook();

        phoneBook.add("Иванов", ("79037658899"));
        phoneBook.add("Петров", ("79087776655"));
        phoneBook.add("Сидоров", ("79068889966"));
        phoneBook.add("Иванов", ("78068645656"));
        phoneBook.add("Смирнов", ("79045556677"));
        phoneBook.add("Смирнов", ("79045553344"));
        phoneBook.add("Петров", ("79045553344"));


        for (String number: phoneBook.get("Петров")) {
            System.out.println(number);
        }

        System.out.println(phoneBook.get("Петров"));
    }
}
