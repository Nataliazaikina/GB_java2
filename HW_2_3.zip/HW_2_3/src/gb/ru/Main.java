package gb.ru;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        list.add(0,"Маша");
        list.add(1,"Света");
        list.add(2,"Катя");
        list.add(3,"Маша");
        list.add(4,"Катя");
        list.add(5,"Света");
        list.add(6,"Оля");
        list.add(7,"Алена");
        list.add(8,"Света");
        list.add(9,"Катя");
        System.out.println(list);
        ArrayList<String> list2;
        list2 = (ArrayList<String>) list.clone();
        int index;
        int index2;
        String symbol = "";
        String nextsymbol;
        for(index = 0; index < list.size(); index++) {

            for(index2 = index; index2 < list.size(); index2++) {
                nextsymbol = list.get(index2);
                if (symbol.equals(nextsymbol)) {
                    list.remove(index2);

                }
            }
            symbol = list.get(index);

        }
        System.out.println(list);

        for (int i = 0; i < list.size(); i++) {
            int quantity = 0;
            for (int j = 0; j < list2.size(); j++){

                if (list.get(i).equals(list2.get(j))) {
                    quantity++;
                }
            }
            System.out.println(list.get(i) + " встречается " + quantity + "раз.");
        }
    }
}
