package phonebook.ru;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        HashMap<String, List<String>> phoneBook = new HashMap<>();
        phoneBook.put("Иванов", new ArrayList<>("79037658899"));
        phoneBook.put("Петров", new ArrayList<>("79087776655"));
        phoneBook.put("Сидоров", new ArrayList<>("79068889966"));
        phoneBook.put("Иванов", new ArrayList<>("78068645656"));
        phoneBook.put("Смирнов", new ArrayList<>("79045556677"));
        phoneBook.put("Смирнов", new ArrayList<>("79045553344"));
        phoneBook.put("Петров", new ArrayList<>("79045553344"));
    }
}
