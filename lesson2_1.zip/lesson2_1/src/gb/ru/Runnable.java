package gb.ru;

public interface Runnable extends Participant{
    boolean run(int length);
}
