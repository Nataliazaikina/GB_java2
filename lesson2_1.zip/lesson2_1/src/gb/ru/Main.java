package gb.ru;

import com.sun.source.tree.CompoundAssignmentTree;

public class Main {
    public static void main(String[] args) {
        Participant[] participants = new Participant[] {
                new Man("Иван", 10, 2),
                new Cat("Барсик", 3, 1),
                new Robot("Федор", 100, 10)
        };

        Obstacle[] obstacles = new Obstacle[] {
                new Treadmill(10),
                new Wall(4),
                new Treadmill(2),
                new Wall(1),
                new Wall(7),
                new Treadmill(500),
        };

        for (Obstacle obstacle : obstacles) {
            for (Participant participant : participants) {
                if (!participant.isStopped()) {
                    if (obstacle instanceof Wall) {
                        ((Wall)obstacle).accept((Jumpable)participant);
                    } else if (obstacle instanceof Treadmill) {
                        ((Treadmill) obstacle).accept((Runnable) participant);
                    }
                }
            }
        }
    }
}
