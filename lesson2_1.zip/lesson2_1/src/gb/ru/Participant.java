package gb.ru;

public interface Participant {
    boolean isStopped();
}
