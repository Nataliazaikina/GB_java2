package gb.ru;

public interface Obstacle {

}
