package gb.ru;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Chat extends JFrame {
    public Chat() {
        setTitle("My Chat");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setBounds(300, 300, 400,400);
        setLayout(null);
        JTextField textField = new JTextField();
        textField.setBounds(10,10,360,220);
        add(textField);
        JTextField messageField = new JTextField();
        messageField.setBounds(10,250,360,60);
        add(messageField);
        JButton button2 = new JButton("Simple Button #2");

        JButton button1 = new JButton("Отправить сообщение");
        add(button1, BorderLayout.SOUTH);
        button1.setBounds(10, 310, 360, 30);
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = messageField.getText();
                textField.setText(text);
                messageField.setText("");
            }
        });

        setVisible(true);

    }

    public static void main(String[] args) {
        new Chat();
    }

}
