package gb.ru;

public class Main2 {
    private static int size = 10000;
    private static int h = size / 2;


    public static void main(String[] args) {
        try {
            method1();
            method2();
        } catch (ArrayIndexOutOfBoundsException e) {
            e.printStackTrace();
        }
    }
    public static void method1() {

        float[] arr = new float[size];
        long a = System.currentTimeMillis();
        for (int i = 0; i < size; i++) {
            arr[i] = 1;
        }
        long b = System.currentTimeMillis();
        System.out.println("\n Время создания массива методом №1: " + (b-a));

        long c = System.currentTimeMillis();
        for (int i = 0; i < size; i++) {
            arr[(int) i] = (float)(arr[(int) i] * Math.sin(0.2f + i / 5) * Math.cos(0.2f + i / 5) * Math.cos(0.4f + i / 2));
        }
        long d = System.currentTimeMillis();
        System.out.println("\n Время выполнения формулы методом №1: " + (d-c));
    }
    public static void method2() {
        try {
            float[] arr = new float[size];
            long a = System.currentTimeMillis();
            for (int i = 0; i < size; i++) {
                arr[i] = 1;
            }
            long b = System.currentTimeMillis();
            System.out.println("\n Время создания массива методом №2: " + (b-a));

            float[] arr1 = new float[h];
            System.arraycopy(arr, 0, arr1, 0, arr1.length);
            float[] arr2 = new float[h];
            System.arraycopy(arr, 0, arr2, 0, arr2.length);

            Thread thread1 = new Thread(() -> {
                for (int i = 0; i < h; i++) {
                    arr1[(int) i] = (float)(arr1[(int) i] * Math.sin(0.2f + i / 5) * Math.cos(0.2f + i / 5) * Math.cos(0.4f + i / 2));
                }
                System.out.print("\n ");
            });

            Thread thread2 = new Thread(() -> {
                for (int i = h; i < size; i++){
                    arr2[(i-h)] = (float)(arr2[(i-h)] * Math.sin(0.2f + i / 5) * Math.cos(0.2f + i / 5) * Math.cos(0.4f + i / 2));
                }
            });

            long c = System.currentTimeMillis();
            thread1.start();
            thread1.join();
            long d = System.currentTimeMillis();
            System.out.println("Время подсчета формулы первой половины массива: " + (d-c));
            long e = System.currentTimeMillis();
            thread2.start();
            thread2.join();
            long f = System.currentTimeMillis();
            System.out.println("\n Время подсчета формулы второй половины массива: " + (f-e));

            float[] arr3 = new float[size];
            System.arraycopy(arr1, 0, arr3, 0, arr1.length);
            System.arraycopy(arr2, 0, arr3, arr1.length, arr2.length);

        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ArrayIndexOutOfBoundsException e) {
            e.printStackTrace();
        }

    }

}
